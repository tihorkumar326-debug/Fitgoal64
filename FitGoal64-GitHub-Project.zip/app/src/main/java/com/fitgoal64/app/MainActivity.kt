package com.fitgoal64.app

import android.content.Context
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import org.json.JSONArray
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

private val Bg = Color(0xFF0B1110)
private val Panel = Color(0xFF15211E)
private val Panel2 = Color(0xFF1D2D28)
private val Green = Color(0xFF62E6A5)
private val Muted = Color(0xFFA2B5AC)
private val White = Color(0xFFF2F7F4)
private val Orange = Color(0xFFFFB86B)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { FitGoalApp(this) }
    }
}

data class DayLog(val date: String, val weight: Float, val calories: Int, val protein: Int, val water: Int)

@Composable
fun FitGoalApp(context: Context) {
    val prefs = remember { context.getSharedPreferences("fitgoal64", Context.MODE_PRIVATE) }
    var tab by remember { mutableStateOf(0) }
    var weight by remember { mutableStateOf(prefs.getFloat("weight", 81f).toString()) }
    var calories by remember { mutableStateOf(prefs.getInt("calories", 0).toString()) }
    var protein by remember { mutableStateOf(prefs.getInt("protein", 0).toString()) }
    var water by remember { mutableIntStateOf(prefs.getInt("water", 0)) }
    var logs by remember {
        mutableStateOf(loadLogs(prefs))
    }
    val targetCalories = 2000
    val targetProtein = 130
    val targetWater = 8

    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = Green, secondary = Orange, background = Bg,
            surface = Panel, onBackground = White, onSurface = White
        )
    ) {
        Scaffold(
            containerColor = Bg,
            bottomBar = {
                NavigationBar(containerColor = Panel) {
                    val labels = listOf("Home", "Track", "Workout", "Food", "Progress")
                    val icons = listOf(Icons.Default.Home, Icons.Default.AddChart, Icons.Default.FitnessCenter, Icons.Default.Restaurant, Icons.Default.ShowChart)
                    labels.forEachIndexed { i, label ->
                        NavigationBarItem(
                            selected = tab == i,
                            onClick = { tab = i },
                            icon = { Icon(icons[i], contentDescription = label) },
                            label = { Text(label, fontSize = 10.sp) },
                            colors = NavigationBarItemDefaults.colors(
                                selectedIconColor = Green, selectedTextColor = Green,
                                indicatorColor = Panel2, unselectedIconColor = Muted,
                                unselectedTextColor = Muted
                            )
                        )
                    }
                }
            }
        ) { padding ->
            when (tab) {
                0 -> HomeScreen(weight, calories, protein, water, logs, { tab = 1 }, Modifier.padding(padding))
                1 -> TrackScreen(
                    weight, { weight = it; prefs.edit().putFloat("weight", it.toFloatOrNull() ?: 81f).apply() },
                    calories, { calories = it; prefs.edit().putInt("calories", it.toIntOrNull() ?: 0).apply() },
                    protein, { protein = it; prefs.edit().putInt("protein", it.toIntOrNull() ?: 0).apply() },
                    water, { water = it; prefs.edit().putInt("water", it).apply() },
                    { 
                        val date = SimpleDateFormat("dd MMM", Locale.getDefault()).format(Date())
                        val entry = DayLog(date, weight.toFloatOrNull() ?: 81f, calories.toIntOrNull() ?: 0, protein.toIntOrNull() ?: 0, water)
                        logs = (logs.filterNot { it.date == date } + entry).takeLast(30)
                        saveLogs(prefs, logs)
                    }, Modifier.padding(padding)
                )
                2 -> WorkoutScreen(Modifier.padding(padding))
                3 -> FoodScreen(Modifier.padding(padding))
                else -> ProgressScreen(logs, Modifier.padding(padding))
            }
        }
    }
}

fun loadLogs(prefs: android.content.SharedPreferences): List<DayLog> {
    return try {
        val arr = JSONArray(prefs.getString("logs", "[]"))
        (0 until arr.length()).map { i ->
            val o = arr.getJSONObject(i)
            DayLog(o.getString("date"), o.getDouble("weight").toFloat(), o.getInt("calories"), o.getInt("protein"), o.getInt("water"))
        }
    } catch (_: Exception) { emptyList() }
}

fun saveLogs(prefs: android.content.SharedPreferences, logs: List<DayLog>) {
    val arr = JSONArray()
    logs.forEach {
        val o = org.json.JSONObject()
        o.put("date", it.date); o.put("weight", it.weight); o.put("calories", it.calories)
        o.put("protein", it.protein); o.put("water", it.water); arr.put(o)
    }
    prefs.edit().putString("logs", arr.toString()).apply()
}

@Composable
fun ScreenColumn(modifier: Modifier = Modifier, content: @Composable ColumnScope.() -> Unit) {
    LazyColumn(
        modifier = modifier.fillMaxSize().background(Bg),
        contentPadding = PaddingValues(start = 18.dp, end = 18.dp, top = 22.dp, bottom = 24.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) { item { Column(verticalArrangement = Arrangement.spacedBy(14.dp), content = content) } }
}

@Composable
fun Header(kicker: String, title: String, subtitle: String? = null) {
    Column(verticalArrangement = Arrangement.spacedBy(5.dp)) {
        Text(kicker.uppercase(), color = Green, fontSize = 11.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.5.sp)
        Text(title, color = White, fontSize = 28.sp, fontWeight = FontWeight.ExtraBold)
        if (subtitle != null) Text(subtitle, color = Muted, fontSize = 13.sp)
    }
}

@Composable
fun CardBox(content: @Composable ColumnScope.() -> Unit) {
    Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(20.dp)) {
        Column(Modifier.fillMaxWidth().padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp), content = content)
    }
}

@Composable
fun Metric(title: String, value: String, target: String, fraction: Float, tint: Color = Green) {
    Column(Modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(6.dp)) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text(title, color = Muted, fontSize = 12.sp)
            Text("$value / $target", color = White, fontWeight = FontWeight.Bold, fontSize = 13.sp)
        }
        LinearProgressIndicator(
            progress = { fraction.coerceIn(0f, 1f) },
            modifier = Modifier.fillMaxWidth().height(8.dp),
            color = tint, trackColor = Panel2
        )
    }
}

@Composable
fun HomeScreen(weight: String, calories: String, protein: String, water: Int, logs: List<DayLog>, onTrack: () -> Unit, modifier: Modifier) {
    ScreenColumn(modifier) {
        Header("YOUR PERSONAL FITNESS HUB", "FitGoal 64", "Stronger every week. Healthier every day.")
        CardBox {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                Column {
                    Text("CURRENT WEIGHT", color = Muted, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    Text("${weight.toFloatOrNull() ?: 81f} kg", color = White, fontSize = 34.sp, fontWeight = FontWeight.ExtraBold)
                    Text("Target: 64 kg  •  Lose 17 kg", color = Green, fontSize = 13.sp)
                }
                Box(Modifier.size(76.dp).background(Panel2, CircleShape), contentAlignment = Alignment.Center) {
                    Icon(Icons.Default.Bolt, null, tint = Green, modifier = Modifier.size(38.dp))
                }
            }
            Text("Your plan: gradual fat loss while protecting strength and muscle.", color = Muted, fontSize = 13.sp)
        }
        Text("TODAY'S TARGETS", color = Green, fontWeight = FontWeight.Bold, fontSize = 12.sp, letterSpacing = 1.sp)
        CardBox {
            Metric("Calories", calories, "2000 kcal", (calories.toFloatOrNull() ?: 0f) / 2000f, Orange)
            Metric("Protein", protein, "130 g", (protein.toFloatOrNull() ?: 0f) / 130f)
            Metric("Water", water.toString(), "8 glasses", water / 8f, Color(0xFF73C9FF))
        }
        CardBox {
            Text("QUICK ACTION", color = Green, fontWeight = FontWeight.Bold, fontSize = 12.sp)
            Text("Log today's food, water and weight to keep your progress moving.", color = Muted, fontSize = 13.sp)
            Button(onClick = onTrack, colors = ButtonDefaults.buttonColors(containerColor = Green, contentColor = Bg), modifier = Modifier.fillMaxWidth()) {
                Icon(Icons.Default.Add, null); Spacer(Modifier.width(8.dp)); Text("Update today's stats", fontWeight = FontWeight.Bold)
            }
        }
        CardBox {
            Text("YOUR WEEKLY RHYTHM", color = Green, fontWeight = FontWeight.Bold)
            Text("Mon • Upper body     Tue • Legs     Wed • Walk / recovery", color = White, fontSize = 13.sp)
            Text("Thu • Upper body     Fri • Full body     Sat • Walk     Sun • Rest", color = Muted, fontSize = 13.sp)
        }
        Text("Saved progress entries: ${logs.size}", color = Muted, fontSize = 12.sp)
    }
}

@Composable
fun TrackScreen(
    weight: String, onWeight: (String) -> Unit,
    calories: String, onCalories: (String) -> Unit,
    protein: String, onProtein: (String) -> Unit,
    water: Int, onWater: (Int) -> Unit,
    onSave: () -> Unit, modifier: Modifier
) {
    ScreenColumn(modifier) {
        Header("DAILY CHECK-IN", "Track your day", "Your entries stay saved on this device.")
        CardBox {
            NumberField("Weight (kg)", weight, onWeight, "81.0")
            NumberField("Calories eaten (kcal)", calories, onCalories, "2000")
            NumberField("Protein (grams)", protein, onProtein, "130")
            Text("Water intake • $water / 8 glasses", color = Muted, fontSize = 13.sp)
            Row(verticalAlignment = Alignment.CenterVertically) {
                OutlinedButton(onClick = { onWater((water - 1).coerceAtLeast(0)) }) { Text("−") }
                Spacer(Modifier.width(12.dp))
                repeat(8) { i ->
                    Box(Modifier.weight(1f).padding(horizontal = 2.dp).height(22.dp)
                        .background(if (i < water) Color(0xFF73C9FF) else Panel2, RoundedCornerShape(6.dp))
                        .clickable { onWater(i + 1) })
                }
                Spacer(Modifier.width(12.dp))
                OutlinedButton(onClick = { onWater((water + 1).coerceAtMost(20)) }) { Text("+") }
            }
            Button(onClick = onSave, modifier = Modifier.fillMaxWidth(), colors = ButtonDefaults.buttonColors(containerColor = Green, contentColor = Bg)) {
                Icon(Icons.Default.Save, null); Spacer(Modifier.width(8.dp)); Text("Save today's progress", fontWeight = FontWeight.Bold)
            }
            Text("Tip: log your weight at a similar time each morning. Use weekly averages rather than daily changes.", color = Muted, fontSize = 12.sp)
        }
    }
}

@Composable
fun NumberField(label: String, value: String, onValue: (String) -> Unit, placeholder: String) {
    OutlinedTextField(
        value = value, onValueChange = onValue, label = { Text(label) },
        placeholder = { Text(placeholder) }, singleLine = true,
        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
        modifier = Modifier.fillMaxWidth(),
        colors = OutlinedTextFieldDefaults.colors(
            focusedBorderColor = Green, focusedLabelColor = Green,
            unfocusedBorderColor = Panel2, focusedTextColor = White, unfocusedTextColor = White
        )
    )
}

@Composable
fun WorkoutScreen(modifier: Modifier) {
    val days = listOf(
        "MONDAY • UPPER BODY" to listOf("Push-ups — 3 × 8–12", "Backpack rows — 3 × 10–12", "Pike push-ups — 3 × 6–10", "Plank — 3 × 30–45 sec"),
        "TUESDAY • LEGS" to listOf("Bodyweight squats — 3 × 12–15", "Reverse lunges — 3 × 10 each leg", "Glute bridges — 3 × 15", "Calf raises — 3 × 20"),
        "WEDNESDAY • RECOVERY" to listOf("Brisk walk — 30 minutes", "Gentle mobility — 5–10 minutes"),
        "THURSDAY • UPPER BODY" to listOf("Push-ups — 3 × 8–12", "Backpack rows — 3 × 10–12", "Backpack shoulder press — 3 × 10", "Side plank — 3 × 20–30 sec each side"),
        "FRIDAY • FULL BODY" to listOf("Squats — 3 × 12", "Push-ups — 3 × 8–12", "Split squats — 3 × 8 each leg", "Backpack rows — 3 × 12"),
        "SATURDAY • CARDIO" to listOf("Brisk walk — 40–45 minutes"),
        "SUNDAY • REST" to listOf("Rest and recover")
    )
    var checked by remember { mutableStateOf(setOf<String>()) }
    ScreenColumn(modifier) {
        Header("HOME TRAINING", "Workout plan", "Start easy. Keep good form. Progress gradually.")
        days.forEach { (day, moves) ->
            CardBox {
                Text(day, color = Green, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                moves.forEach { move ->
                    Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth().clickable {
                        checked = if (move in checked) checked - move else checked + move
                    }.padding(vertical = 4.dp)) {
                        Checkbox(checked = move in checked, onCheckedChange = { yes -> checked = if (yes) checked + move else checked - move }, colors = CheckboxDefaults.colors(checkedColor = Green))
                        Text(move, color = if (move in checked) Muted else White, fontSize = 13.sp)
                    }
                }
            }
        }
        Text("When all sets feel controlled and you can do the top of the rep range, add a little backpack weight or choose a harder variation.", color = Muted, fontSize = 12.sp)
    }
}

@Composable
fun FoodScreen(modifier: Modifier) {
    val meals = listOf(
        Triple("BREAKFAST • 8 AM", "3 eggs + oats with milk + fruit", "Approx. 25–30 g protein"),
        Triple("LUNCH • 1 PM", "2 rotis + dal + curd + vegetables + salad", "Approx. 20–25 g protein"),
        Triple("SNACK • 5 PM", "Roasted chana + milk + fruit", "Approx. 15–20 g protein"),
        Triple("DINNER • 8 PM", "Soy chunks or paneer + 1–2 rotis + vegetables", "Approx. 30–40 g protein")
    )
    ScreenColumn(modifier) {
        Header("INDIAN VEGETARIAN + EGGS", "Food guide", "Aim around 1,900–2,100 kcal and 120–140 g protein as a starting point.")
        CardBox {
            Text("DAILY NUTRITION GUIDE", color = Green, fontWeight = FontWeight.Bold)
            Text("Protein: 120–140 g  •  Calories: start near 2,000 kcal", color = White, fontSize = 14.sp)
            Text("Adjust portions after 2–3 weeks using your weight trend, energy and strength.", color = Muted, fontSize = 12.sp)
        }
        meals.forEach { (time, food, protein) ->
            CardBox {
                Text(time, color = Green, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                Text(food, color = White, fontWeight = FontWeight.SemiBold)
                Text(protein, color = Muted, fontSize = 12.sp)
            }
        }
        CardBox {
            Text("GOOD PROTEIN OPTIONS", color = Green, fontWeight = FontWeight.Bold)
            Text("Eggs • soy chunks • paneer • milk • curd • dal • rajma • chana • moong • Greek-style yogurt", color = White, fontSize = 13.sp)
        }
        Text("Food estimates vary by portion and recipe. Limit excess oil and sugary drinks; no need to eliminate roti or rice.", color = Muted, fontSize = 12.sp)
    }
}

@Composable
fun ProgressScreen(logs: List<DayLog>, modifier: Modifier) {
    ScreenColumn(modifier) {
        Header("YOUR JOURNEY", "Progress", "Save regular check-ins to build your personal trend.")
        CardBox {
            Text("WEIGHT HISTORY", color = Green, fontWeight = FontWeight.Bold)
            if (logs.isEmpty()) {
                Text("No saved entries yet. Visit Track and save your first check-in.", color = Muted, fontSize = 13.sp)
            } else {
                WeightChart(logs)
                logs.takeLast(10).reversed().forEach {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text(it.date, color = Muted, fontSize = 12.sp)
                        Text("${it.weight} kg", color = White, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                    }
                }
            }
        }
        CardBox {
            Text("YOUR TARGET", color = Green, fontWeight = FontWeight.Bold)
            Text("81 kg starting point → 64 kg goal", color = White, fontSize = 15.sp, fontWeight = FontWeight.Bold)
            Text("Aim for gradual progress, roughly 0.4–0.7 kg per week. Your health and strength matter more than the scale.", color = Muted, fontSize = 12.sp)
        }
    }
}

@Composable
fun WeightChart(logs: List<DayLog>) {
    val values = logs.takeLast(12).map { it.weight }
    if (values.isEmpty()) return
    val min = (values.minOrNull()!! - 1f).coerceAtLeast(0f)
    val max = values.maxOrNull()!! + 1f
    Canvas(Modifier.fillMaxWidth().height(150.dp)) {
        val left = 12f; val right = size.width - 12f
        val top = 12f; val bottom = size.height - 12f
        repeat(4) { i ->
            val y = top + (bottom - top) * i / 3f
            drawLine(Panel2, Offset(left, y), Offset(right, y), strokeWidth = 1.dp.toPx())
        }
        val points = values.mapIndexed { i, v ->
            val x = if (values.size == 1) (left + right) / 2 else left + (right - left) * i / (values.size - 1)
            val y = bottom - (v - min) / (max - min).coerceAtLeast(0.1f) * (bottom - top)
            Offset(x, y)
        }
        points.zipWithNext().forEach { (a, b) -> drawLine(Green, a, b, strokeWidth = 3.dp.toPx()) }
        points.forEach { drawCircle(Green, radius = 5.dp.toPx(), center = it) }
    }
}

@Composable
fun FitGoalPreviewText() {
    Text("FitGoal 64", color = Green)
}
